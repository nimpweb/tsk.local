/*! s.js (C) 2019-present SheetJS -- https://sheetjs.com */
/* vim: set ts=2: */

export { Workbook } from "./s/Workbook";
export { get_XLSX, set_XLSX } from "./s/XLSXWrapper";